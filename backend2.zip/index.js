// Importar dependências
const express = require('express');
const multer = require('multer');
const path = require('path');
const mongoose = require('mongoose');
const cors = require('cors'); // Adicionado

const app = express();
const PORT = 3000;

// Conectar ao MongoDB
mongoose.connect('mongodb+srv://hugo701545:rkLadM8PCvyLNVLI@cluster0.6naql.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'Erro de conexão ao MongoDB:'));
db.once('open', () => {
    console.log('Conectado ao MongoDB!');
});

// Definir o schema e o modelo de Produto
const productSchema = new mongoose.Schema({
    name: { type: String, required: true },
    description: String,
    quantity: { type: Number, required: true },
    photo: String,
});

const Product = mongoose.model('Product', productSchema);

// Configurar middleware para JSON, CORS e arquivos estáticos
app.use(cors({
    origin: '*', // Substitua pelo domínio do frontend ou use '*' para permitir todas as origens
    methods: ['GET', 'POST', 'PUT', 'DELETE'], // Métodos permitidos
    credentials: true // Permitir cookies ou cabeçalhos de autenticação
}));
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Configuração do multer para upload de fotos
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}-${file.originalname}`);
    },
});
const upload = multer({ storage });

// Rotas da API

// 1. Listar todos os produtos
app.get('/products', async (req, res) => {
    try {
        const products = await Product.find();
        res.json(products);
    } catch (err) {
        res.status(500).json({ error: 'Erro ao listar produtos.' });
    }
});

// 2. Obter um produto pelo ID
app.get('/products/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const product = await Product.findById(id);

        if (!product) {
            return res.status(404).json({ error: 'Produto não encontrado.' });
        }

        res.json(product);
    } catch (err) {
        res.status(500).json({ error: 'Erro ao buscar produto.' });
    }
});

// 3. Criar um novo produto
app.post('/products', upload.single('photo'), async (req, res) => {
    try {
        const { name, description, quantity } = req.body;
        const photo = req.file ? req.file.path : null;

        if (!name || !quantity) {
            return res.status(400).json({ error: 'Nome e quantidade são obrigatórios.' });
        }

        const newProduct = new Product({
            name,
            description,
            quantity,
            photo,
        });

        await newProduct.save();

        res.status(201).json(newProduct);
    } catch (err) {
        res.status(500).json({ error: 'Erro ao criar produto.' });
    }
});

// 4. Atualizar um produto
app.put('/products/:id', upload.single('photo'), async (req, res) => {
    try {
        const { id } = req.params;
        const { name, description, quantity } = req.body;
        const photo = req.file ? req.file.path : null;

        const product = await Product.findById(id);

        if (!product) {
            return res.status(404).json({ error: 'Produto não encontrado.' });
        }

        product.name = name || product.name;
        product.description = description || product.description;
        product.quantity = quantity || product.quantity;
        if (photo) product.photo = photo;

        await product.save();

        res.json({ message: 'Produto atualizado com sucesso.', product });
    } catch (err) {
        res.status(500).json({ error: 'Erro ao atualizar produto.' });
    }
});

// 5. Deletar um produto
app.delete('/products/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const product = await Product.findById(id);

        if (!product) {
            return res.status(404).json({ error: 'Produto não encontrado.' });
        }

        await Product.findByIdAndDelete(id);

        res.json({ message: 'Produto deletado com sucesso.' });
    } catch (err) {
        res.status(500).json({ error: 'Erro ao deletar produto.' });
    }
});

// Iniciar o servidor
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
