import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, Button } from 'react-native';
import axios from 'axios';

export default function ProductList({ navigation }) {
    const [products, setProducts] = useState([]);

    useEffect(() => {
        fetchProducts();
    }, []);

    const fetchProducts = async () => {
        try {
            const response = await axios.get('http://localhost:3000/products');
            console.log(response);
            setProducts(response.data);
        } catch (error) {
            console.log(error);
            console.error('Erro ao buscar produtos:', error);
        }
    };

    return (
        <View style={styles.container}>
            <Button title="Adicionar Produto" onPress={() => navigation.navigate('ProductForm')} />
            <FlatList
                data={products}
                keyExtractor={(item) => item._id}
                renderItem={({ item }) => (
                    <TouchableOpacity
                        style={styles.productItem}
                        onPress={() => navigation.navigate('ProductDetails', { product: item })}
                    >
                        <Text style={styles.productName}>{item.name}</Text>
                        <Text style={styles.productQuantity}>Quantidade: {item.quantity}</Text>
                    </TouchableOpacity>
                )}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
    },
    productItem: {
        padding: 16,
        backgroundColor: '#f9f9f9',
        marginVertical: 8,
        borderRadius: 8,
    },
    productName: {
        fontSize: 18,
        fontWeight: 'bold',
    },
    productQuantity: {
        color: '#555',
    },
});
