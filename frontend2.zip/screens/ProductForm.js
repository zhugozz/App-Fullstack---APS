import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet, Alert, Image, TouchableOpacity, Text } from 'react-native';
import axios from 'axios';
import * as ImagePicker from 'react-native-image-picker';

export default function ProductForm({ navigation }) {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [quantity, setQuantity] = useState('');
    const [image, setImage] = useState(null);

    const handleSave = async () => {
        const formData = new FormData();
        formData.append('name', name);
        formData.append('description', description);
        formData.append('quantity', Number(quantity));
        if (image) {
            formData.append('image', {
                uri: image.uri,
                name: image.fileName || 'image.jpg',
                type: image.type || 'image/jpeg',
            });
        }

        try {
            await axios.post('http://localhost:3000/products', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });
            Alert.alert('Sucesso', 'Produto criado com sucesso!');
            navigation.goBack();
        } catch (error) {
            console.error('Erro ao criar produto:', error);
            Alert.alert('Erro', 'Não foi possível criar o produto.');
        }
    };

    const handleSelectImage = () => {
        ImagePicker.launchImageLibrary(
            { mediaType: 'photo', selectionLimit: 1 },
            (response) => {
                if (response.didCancel) {
                    console.log('Seleção de imagem cancelada.');
                } else if (response.errorMessage) {
                    console.error('Erro ao selecionar imagem:', response.errorMessage);
                    Alert.alert('Erro', 'Ocorreu um problema ao acessar suas fotos.');
                } else if (response.assets && response.assets.length > 0) {
                    console.log('Imagem selecionada:', response.assets[0]);
                    setImage(response.assets[0]);
                }
            }
        );
    };

    return (
        <View style={styles.container}>
            <TextInput
                style={styles.input}
                placeholder="Nome"
                value={name}
                onChangeText={setName}
            />
            <TextInput
                style={styles.input}
                placeholder="Descrição"
                value={description}
                onChangeText={setDescription}
            />
            <TextInput
                style={styles.input}
                placeholder="Quantidade"
                value={quantity}
                onChangeText={setQuantity}
                keyboardType="numeric"
            />
            <TouchableOpacity style={styles.imagePicker} onPress={handleSelectImage}>
                <Text style={styles.imagePickerText}>Selecionar Imagem</Text>
            </TouchableOpacity>
            {image && <Image source={{ uri: image.uri }} style={styles.preview} />}
            <Button title="Salvar" onPress={handleSave} />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
    },
    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 8,
        padding: 8,
        marginBottom: 16,
    },
    imagePicker: {
        backgroundColor: '#ddd',
        padding: 10,
        alignItems: 'center',
        marginBottom: 16,
        borderRadius: 8,
    },
    imagePickerText: {
        color: '#333',
    },
    preview: {
        width: '100%',
        height: 200,
        marginBottom: 16,
        borderRadius: 8,
    },
});
